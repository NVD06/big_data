from kafka import KafkaProducer
import requests
from bs4 import BeautifulSoup
import json
import time

KAFKA_BROKER = 'kafka:9092'
TOPIC_NAME = 'stock_news'
MAX_ARTICLES = 20  # Giới hạn tổng số tin tức thu thập


def check_kafka_connection(retries=5, delay=5):
    for attempt in range(retries):
        try:
            producer = KafkaProducer(bootstrap_servers=KAFKA_BROKER)
            producer.close()
            print("✅ Kafka is reachable!")
            return True
        except Exception as e:
            print(f"❌ Kafka connection failed (attempt {attempt + 1}/{retries}): {e}")
            time.sleep(delay)
    return False


if not check_kafka_connection():
    print("❌ Could not connect to Kafka after retries. Exiting.")
    exit(1)

producer = KafkaProducer(bootstrap_servers=KAFKA_BROKER, value_serializer=lambda v: json.dumps(v).encode('utf-8'))


def crawl_news(url):
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()  # Kiểm tra lỗi HTTP
        soup = BeautifulSoup(response.text, 'html.parser')
        articles = soup.find_all('article') or soup.find_all('div', class_='title')
        news_data = []
        for article in articles:
            title_tag = article.find('h2') or article.find('a')
            if title_tag and title_tag.text.strip():
                news_data.append({'title': title_tag.text.strip(), 'timestamp': time.time(), 'source': url})
            if len(news_data) >= MAX_ARTICLES // 3: 
                break
        return news_data
    except requests.RequestException as e:
        print(f"❌ Request error for {url}: {e}")
    except Exception as e:
        print(f"❌ Error parsing {url}: {e}")
    return []


sources = [
    'https://vietstock.vn/chung-khoan.htm',
    'https://cafef.vn/thi-truong-chung-khoan.chn',
    'https://vnexpress.net/kinh-doanh/chung-khoan'
]

total_articles = 0
while total_articles < MAX_ARTICLES:
    for source in sources:
        news = crawl_news(source)
        for article in news:
            try:
                producer.send(TOPIC_NAME, article)
                print(f"✅ Sent: {article['title']} from {article['source']}")
                total_articles += 1
                if total_articles >= MAX_ARTICLES:
                    break
            except Exception as e:
                print(f"❌ Kafka send error: {e}")
        if total_articles >= MAX_ARTICLES:
            break
    time.sleep(3600)  # Đợi 60 phút trước khi chạy lại

print(f"✅ Đã thu thập và gửi {total_articles} tin tức đến Kafka. Kết thúc crawler.")
producer.close()
